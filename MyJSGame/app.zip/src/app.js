
var HelloWorldLayer = cc.Layer.extend({
    sprite:null,
    ctor:function () {
        this._super();

        //初始化
        mo.winSize = null;
        mo.director = cc.director;

        this.sprite = new cc.Sprite("res/bg_loading.png");
        this.addChild(this.sprite);
        this.sprite.x = cc.winSize.width/2;
        this.sprite.y = cc.winSize.height/2;

        this.addChild(new loginLayer());

        return true;
    }
});

var HelloWorldScene = cc.Scene.extend({
    onEnter:function () {
        this._super();
        var layer = new HelloWorldLayer();
        this.addChild(layer);
    }
});

