
var res = {
    HelloWorld_png : "res/HelloWorld.png",
    CloseNormal_png : "res/CloseNormal.png",
    CloseSelected_png : "res/CloseSelected.png",
    bg_loading_png : "res/bg_loading.png",
    fsa : "res/fonts/han.ttf"
};

var g_resources =
    [
        "res/cocostudio/ccs_Login.json",
        "res/cocostudio/bg_loading.png"
    ];

for (var i in res) {
    g_resources.push(res[i]);
}