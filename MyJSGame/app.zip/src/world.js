/**
 * Created by gongxun on 15/7/16.
 */

var World = function () {
    var that = {};

    that.showMsg = function (){
        return "hehe";
    };

    return that;
};


mo.world = World();