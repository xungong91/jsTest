/**
 * Created by gongxun on 15/7/30.
 */

var loginLayer = BaseTestLayer.extend({
    editBoxUserName : null,
    editBoxPwd : null,

    ctor: function () {
        this._super();
        var node,
            file = "res/cocostudio/ccs_Login.json";
        cc.log("ccs.load : %s", file);
        var json = ccs.load(file);
        node = json.node;
        this.addChild(node);

        //login button
        var Button_login = ccui.helper.seekWidgetByName(node, "Button_login");
        Button_login.addTouchEventListener(this.touchEvent,this);

        //editBox username
        //this.editBoxUserName = new cc.EditBox(cc.size(400, 55), new cc.Scale9Sprite("res/bg_ring.png"));
        //this.editBoxUserName.setPlaceholderFontColor(cc.color(255, 0, 0));
        //this.editBoxUserName.setPlaceHolder("请输入用户名:");
        //this.editBoxUserName.setPlaceholderFontSize(35);
        //this.editBoxUserName.x = 320;
        //this.editBoxUserName.y = 345;
        //this.editBoxUserName.setFontColor(cc.color(251, 250, 0));
        //this.editBoxUserName.setFontSize(35);
        //this.addChild(this.editBoxUserName);

        //editBox pwd
        //this.editBoxPwd = new cc.EditBox(cc.size(400, 55), new cc.Scale9Sprite("res/bg_ring.png"));
        //this.editBoxPwd.setPlaceholderFontColor(cc.color(255, 0, 0));
        //this.editBoxPwd.setPlaceHolder("请输入密码:");
        //this.editBoxPwd.setPlaceholderFontSize(35);
        //this.editBoxPwd.x = 320;
        //this.editBoxPwd.y = 240;
        //this.editBoxPwd.setFontColor(cc.color(251, 250, 0));
        //this.editBoxPwd.setFontSize(35);
        //this.addChild(this.editBoxPwd);


        var top = new cc.LabelTTF("我就试试", "res/fonts/han.ttf", 40);
        top.x = 320;
        top.y = 200;
        this.addChild(top);
    },
    onEnter: function ()
    {
        this._super();
    },
    onExit: function() {
        ccs.actionManager.releaseActions();
        this._super();
    },
    title: function () {
        return "loadSceneEdtiorFile Test";
    },
    touchEvent: function (sender, type) {
        if (type == ccui.Widget.TOUCH_ENDED){

            cc.log("login :" + this.editBoxUserName.getString() + this.editBoxPwd.getString());
        }
    }
});