/**
 * Created by gongxun on 15/7/30.
 */


var BaseTestLayer = cc.LayerGradient.extend({
    ctor: function () {
        if (arguments.length === 0) {
            this._super(cc.color(0, 0, 0, 255), cc.color(98, 99, 117, 255));
        } else {
            this._super.apply(this, arguments);
        }
    },

    onExit: function () {
        ccs.armatureDataManager.clear();
        ccs.sceneReader.clear();
        ccs.actionManager.clear();
        ccs.uiReader.clear();
        this._super();
    },

    initSize:function(node){
        var winSize = cc.director.getWinSize();
        var scale = winSize.height / 320;
        node.scale = scale;
        node.x = (winSize.width - 480 * scale) / 2;
        node.y = (winSize.height - 320 * scale) / 2;
    }
});