/**
 * Created by gongxun on 15/8/2.
 */
var jsFiles = [
    "src/app.js",
    "src/scene/baseLayer.js",
    "src/scene/loginLayer.js",
    "src/resource.js"
];